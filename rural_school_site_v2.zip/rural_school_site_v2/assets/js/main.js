
const toggle=document.querySelector('.nav-toggle');const links=document.querySelector('.nav-links');
if(toggle&&links){toggle.addEventListener('click',()=>links.classList.toggle('open'))}
document.querySelectorAll('form[data-enhance]').forEach(f=>{
  f.addEventListener('submit',e=>{e.preventDefault();const b=f.querySelector('button[type=submit]');if(b)b.disabled=true;
    setTimeout(()=>{alert('Thank you! Your form was submitted.');f.reset();if(b)b.disabled=false;},400)})
})
