
# Rural Elementary School Website (Static Template, v2)

A clean, mobile-friendly multi-page website for an educational institution.

## Pages
- Home: `index.html`
- About: `about.html`
- Academics: `academics.html`
- Admissions: `admissions.html`
- Facilities: `facilities.html`
- News: `news.html`
- Contact: `contact.html`
- Donate: `donate.html`

## How to Use
1. Replace text and images with your real content (assets/img/).
2. Customize colors in `assets/css/style.css` (variables at the top).
3. Swap placeholder forms with a real service (Formspree, Google Forms) or payment gateway.

## Publish (GitHub Pages)
- Create a new GitHub repository and upload these files.
- In **Settings → Pages**, set Source to *Deploy from a branch*.
- Choose the `main` branch and folder `/ (root)`.
- Your site will be live at `https://<username>.github.io/<repo>/`.

## Publish (Any Hosting)
- Upload the folder to your hosting provider’s `public_html`.
- Map your custom domain.

## License
Use and modify freely.
